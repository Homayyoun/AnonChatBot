<?php
/**
 * Pagination item template
 */

?>
<div class="jet-filters-pagination__link">/% $value %/</div>